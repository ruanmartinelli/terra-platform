
conf = {};

conf.s_sourceDir = 'files_vmx'
conf.s_posfix = '.vmx'
conf.s_backupDir = 'backup'
conf.n_sleepTimeS = 3;
conf.exit = false



conf.vID = 227;


return conf;